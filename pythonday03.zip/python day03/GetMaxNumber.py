#!/usr/bin/python3

grade = None
maxGrade = None
text = "Please input grade:"
textError = "Input Error!"
textMax = "The max number is:"
counter = 1

while counter <= 3:
    grade = input(text)
    try:
        grade = float(grade)
    except:
        print(textError)
        exit()
    if(maxGrade == None):
        maxGrade = grade
    else:
        maxGrade = grade if grade > maxGrade else maxGrade
    counter += 1
print(textMax, maxGrade)
