#!/usr/bin/python3
list31Day = ['1', '3', '5', '7', '8', '10', '12']
list30Day = ['4', '6', '9', '11']

text = "The mouth have:"
textInputError = "Input Error"
mouthInput = input("Please write mouth:")
if(not mouthInput.isdigit()):
    print(textInputError)
    exit()
if(mouthInput == '2'):
    year = input("Please write year:")
    try:
        year = int(year)
    except:
        print(textInputError)
        exit()
    if(year % 400 == 0 or (year % 4 == 0 and year % 100 != 0)):
        print(text, 29, "days")
    else:
        print(text, 28, "days")
    exit()
if(mouthInput not in list31Day):
    if(mouthInput not in list30Day):
        print(textInputError)
    else:
        print(text, 30, "days")
else:
    print(text, 31, "days")
