#!/usr/bin/python3
a = input("请输入身高cm:")
if a.isdigit() == True:
    a = float(a)
else:
    print("输入错误！")
    exit()
b = input('请输入体重kg:')
if b.isdigit() == True:
    b = float(b)
else:
    print("输入错误！")
    exit()
z = input("请输入您到性别(１为男性，２为女性):")
if z == '1':
    bb = (a - 80) * 0.7
elif z == '2':
    bb = (a - 70) * 0.6
else:
    print("输入错误！")
    exit()
del a
cb = (b - bb) / bb
if bb <= 0:
    print("计算失败，请等待下一版本！")
elif cb <= 0:
    print("您并不超重！")
else:
    print("标准体重是：", bb, "超重比是：", cb)
