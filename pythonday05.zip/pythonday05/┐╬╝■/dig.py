
#产生４个1-9到不同的随机数
#用到 random 模块
#1 导入 import 

import random

c, d, e, f = random.sample([1,2,3,4,5,6,7,8,9], 4)

#print("c=%d" % c)
#print("d=%d" % d)
#print("e=%d" % e)
#print("f=%d" % f)


#比较
#m ---- c

while True:
    A = 0
    B = 0
    m = input("请输入第1个数:")
    m = int(m)
    n = input("请输入第2个数:")
    n = int(n)
    
    x = input("请输入第3个数:")
    x = int(x)
    
    y = input("请输入第2个数:")
    y = int(y)
    
    print("m=%d n = %d x=%d y=%d" % (m, n, x, y))
    
    # m --- c
    if m == c:
        A += 1
    elif m == d or m == e or m == f:
        B += 1
    
    #n ----d
    if n == d:
        A += 1
    elif n == c or n == e or n == f:
        B += 1
    
    #x -- e
    if x == e:
        A += 1
    elif x == c or x == d or x == f:
        B += 1
    
    #y -- f
    if y == f:
        A += 1
    elif y == c or y == d or y == e:
        B += 1
    
    print("%dA%dB" % (A,B))

    if A == 4:
        break







   
















