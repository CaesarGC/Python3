#!/usr/bin/python3
# coding:utf-8

import random

# 数字越大,难度越大
difficulty = None
exampleStr = None

listExit = ["quit", "exit", "q", "e"]

textError = "输入错误，请重新输入，退出请输入exit/quit/q/e:"
textBegin = "请选择游戏难度,1:简单,2:普通,3:困难.(exit/quit/q/e可退出)"
inputAgain = "是否继续游戏？（y/n）"
textGameRule = '    欢迎来到猜数字小游戏，系统会随机生成几个不重复的数字，玩家需要猜测这些数字的号码和顺序，如果猜对号码并且猜对号码在几个数字中的位置，则为A，如果号码正确，但是位置不正确，则为B。每次结果的表现形式为?A?B,如2A2B,则说明有两个数字号码猜对了位置也猜对了,有2个数字号码猜对了,但是位置猜错了.以上就是游戏规则,祝您玩的愉快.'
textWin = "全服通告,恭喜玩家,猜测正确!希望玩家,再接再厉,再创辉煌!"

strlist = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

# 入场提示
print(textGameRule)
# 选择难度
value = input(textBegin)
while difficulty == None or exampleStr == None:
    if value == '1':
        difficulty = 3
        exampleStr = '123'
    elif value == '2':
        difficulty = 4
        exampleStr = '1234'
    elif value == '3':
        difficulty = 6
        exampleStr = '123456'
    elif value in listExit:
        exit()
    else:
        print(textError)

textInput = "请输入%s位数字(建议:数字不要重复哦)，如%s。exit/quit/q/e可退出,输入answer可以显示答案哦:" % (
    difficulty, exampleStr)

while True:
    # 创建随机数
    count = 0
    numberList = random.sample(strlist, difficulty)
    number = None
    while count < difficulty:
        if number == None:
            number = numberList[count]
        else:
            number += numberList[count]
        count += 1

    while True:
        # 用户输入数字
        guessNumber = input(textInput)
        if guessNumber in listExit:
            exit()
        elif guessNumber == 'answer':
            print(number)
            continue
        if len(guessNumber) != difficulty:
            print(textError)
            continue
        try:
            text = int(guessNumber)
        except:
            print(textError)
            continue
        # 对用户输入进行评分
        if guessNumber == number:
            print(textWin)
            value = input(inputAgain)
            if value != 'y':
                exit()
            else:
                break
        else:
            # 判断有几个A,几个B
            count = 0
            ANumber = 0
            BNumber = 0
            while count < difficulty:
                if guessNumber[count] == number[count]:
                    ANumber += 1
                else:
                    countTwo = 0
                    while countTwo < difficulty:
                        if guessNumber[count] == number[countTwo]:
                            BNumber += 1
                        countTwo += 1
                count += 1
            ABTest = "您这次的成绩为" + \
                (str(ANumber)+'A'+str(BNumber)+'B')+"!请再接再厉,早创辉煌!"
            print(ABTest)
